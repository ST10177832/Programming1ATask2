/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tests;
import com.mycompany.prog1atask2.Message;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Before; 

/**
 *
 * @author User
 */
public class MessageTest {
 private Message message1;
  private Message message2;  
  
  @Before
  public void setUp() {
      message1= new Message("+27718693002", "Hi Mike, can you join us for dinner tonight");
        message2 = new Message("08575975889", "Hi Keegan, did you receive the payment?");
    }

   // Test length of the message
    @Test
    public void testMessage1Length() {
        assertEquals("Message is ready to send.", message1.checkMessageLength());
    }

    @Test
    public void testMessage2Length() {
        assertEquals("Message ready to send.", message2.checkMessageLength());
    }

// Test format recipient 
    @Test
    public void testMessage1Recipient() {
         assertEquals("Cell phone number successfully captured.", message1.checkRecipientCell());
    }

    @Test
    public void testMessage2Recipient() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", 
                     message2.checkRecipientCell());
    }

   // Test MessageID
    @Test
    public void testMessage1ID() {
        String id = message1.checkMessageID();
        assertNotNull("Message ID should be generated", id);
        assertTrue("Message ID should not exceed 10 chars", id.length() <= 10);
    }

    @Test
    public void testMessage2ID() {
        String id = message2.checkMessageID();
        assertNotNull("Message ID should be generated", id);
        assertTrue("Message ID should not exceed 10 chars", id.length() <= 10);
    }

    // Test message hash
    @Test
    public void testMessage1Hash() {
        String hash = message1.createMessageHash();
        assertEquals("00:0:HITONIGHT", hash); // matches your test data
    }

    @Test
    public void testMessage2Hash() {
        String hash = message2.createMessageHash();
        assertNotNull("Message Hash should be generated", hash);
        assertTrue("Message Hash should be uppercase", hash.equals(hash.toUpperCase()));
    }

  // Test SentMessages Options 
    @Test
    public void testMessage1Send() {
        assertEquals("Message successfully sent.", message1.sentMessage("Send"));
    }

    @Test
    public void testMessage1Discard() {
        assertEquals("Press 0 to delete message.", message1.sentMessage("Disregard"));
    }

    @Test
    public void testMessage1Store() {
        assertEquals("Message successfully stored.", message1.sentMessage("Store"));
    }

    // Test total messages sent 
    @Test
    public void testTotalMessagesSent() {
        // Check if only message1 is  sent
        message1.sentMessage("Send");
        message2.sentMessage("Disregard");
        message2.sentMessage("Store");

        int totalSent = message1.returnTotalMessages();
        assertEquals(1, totalSent);
  }

    }



    

