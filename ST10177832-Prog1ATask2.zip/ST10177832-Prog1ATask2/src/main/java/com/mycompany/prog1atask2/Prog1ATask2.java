/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog1atask2;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.simple.JSONObject;
/**
 *
 * @author User
 */
public class Prog1ATask2 {

    public static void main(String[] args) {
        List messages = new ArrayList<>();
        int totalMessages = 0;

    // Welcome message
    JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

    while (true) {
        // Numeric menu for user options
        String menu = "Choose an option:\n" +
                      "1. Send Messages\n" +
                      "2. Show recently sent messages (Coming Soon).\n" +
                      "3. Quit";
        String choice = JOptionPane.showInputDialog(menu);

        switch (choice) {
            case "1":
                // How many messages does the user wish to enter
                int numMessagesToSend = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you wish to enter?"));

                for (int i = 0; i < numMessagesToSend; i++) {
                    String messageId = String.valueOf(new Random().nextInt(900000000) + 100000000);
                    String recipient = JOptionPane.showInputDialog("Enter recipient cell number:");
                    String messageContent = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
 if (messageContent.length() > 250) {
                        JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
                        continue;
                    }

                    
                    Message newMessage = new Message(messageId, recipient, messageContent);
                    if (newMessage.checkMessageID() && newMessage.checkRecipientCell()) {
                        messages.add(newMessage);
                        totalMessages++;
                        newMessage.incrementMessageCount();
                        JOptionPane.showMessageDialog(null, String.format("Message sent!\nID: %s\nRecipient: %s\nMessage: %s\nHash: %s",
                                newMessage.getMessageId(), newMessage.getRecipient(), newMessage.getMessage(), newMessage.getMessageHash()));
                    }
                }
                break;

            case "2":
                JOptionPane.showMessageDialog(null, "Coming Soon.");
                break;

            case "3":
                // Display total number of messages sent and exit
                JOptionPane.showMessageDialog(null, "Total number of messages sent: " + totalMessages);
 return;

            default:
                JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");

}

    }
    }
}

