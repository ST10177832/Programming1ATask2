package com.mycompany.prog1atask2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.json.simple.JSONObject;
/**
 *
 * @author User
 */
public class Message {

    public static boolean checkUserName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private String messageId;
    private String recipient;
    private String message;
    private static int messageCount = 0;

    public Message(String messageId, String recipient, String message) {
        this.messageId = messageId; 

        this.recipient = recipient;
        this.message = message;
    }

    public boolean checkMessageID() {
        return messageId.matches("\\d{10}");
    }

    public boolean checkRecipientCell() {
        return recipient.startsWith("+") && recipient.length() >= 10;
    }

    public String sentMessage() {
        String[] options = {"Send message", "Store message to send later", "Disregard message"};
        int choice = javax.swing.JOptionPane.showOptionDialog(null,
                "Choose an action",
                "Message Options",
                javax.swing.JOptionPane.DEFAULT_OPTION,
                javax.swing.JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
  options[0]);

        if (choice == 0) return "send message";
        else if (choice == 1) return "store message to send later";
        else return "disregard message";
    }

    public String getMessageHash() {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(message.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return "Error generating hash";
        }
    }
    public void storeMessageToJson() {
        JSONObject obj = new JSONObject();
        obj.put("messageId", messageId);
        obj.put("recipient", recipient);
        obj.put("message", message);
        obj.put("messageHash", getMessageHash());
         try (FileWriter file = new FileWriter("stored_messages.json", true)) {
            file.write(obj.toJSONString() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void incrementMessageCount() {
        messageCount++;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;

}
 public void setMessage(String message) {
     this.message = message;
 }  
   public void setRecipient(String recipient) {
       this.recipient = recipient; 
   }
   public void setMessageId(String messageId) {
       this.messageId = messageId;
   }
}
